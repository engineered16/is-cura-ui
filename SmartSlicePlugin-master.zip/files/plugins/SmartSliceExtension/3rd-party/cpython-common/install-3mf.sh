rm -f teton-3mf.tar.gz
wget -O teton-3mf.tar.gz https://files.pythonhosted.org/packages/13/7e/0b1db85f02300b94233d728886eadfdab1dd5baa5fcacaaa9cdaf4b06bdd/teton-3mf-19.1.7.tar.gz
tar -zxvf teton-3mf.tar.gz
rm teton-3mf.tar.gz
